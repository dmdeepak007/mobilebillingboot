package com.cg.moviebooking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.cg.moviebooking.beans.Address;
import com.cg.moviebooking.beans.Bill;
import com.cg.moviebooking.beans.Customer;
import com.cg.moviebooking.beans.MovieDetails;
import com.cg.moviebooking.beans.Ticket;
import com.cg.moviebooking.daoservices.BillDAO;
import com.cg.moviebooking.daoservices.CustomerDAO;
import com.cg.moviebooking.daoservices.MovieDetailsDAO;
import com.cg.moviebooking.daoservices.TicketDAO;
import com.cg.moviebooking.exceptions.BillDetailsNotFoundException;
import com.cg.moviebooking.exceptions.CustomerDetailsNotFoundException;
import com.cg.moviebooking.exceptions.InvalidNumberOfTickets;
import com.cg.moviebooking.exceptions.MovieBookingServiceDownException;
import com.cg.moviebooking.exceptions.MovieDetailsNotFoundException;
import com.cg.moviebooking.exceptions.PasswordDoesnotMatchException;
import com.cg.moviebooking.exceptions.TicketDetailsNotfoundException;

@Component("bookingservices")
public class BookingServicesImpl implements BookingServices{
	@Autowired
	private CustomerDAO customerDAO;
	@Autowired
	private BillDAO billDAO;
	@Autowired
	private MovieDetailsDAO movieDetailsDAO;
	@Autowired
	private TicketDAO ticketDAO;
	

	@Override
	public int acceptCustomerDetails(String name, String emailId, String dateOfBirth, String password, String city,
			String state, int pinCode) throws MovieBookingServiceDownException {
	Customer customer = new Customer(name, emailId, dateOfBirth, password, new Address(city, state, pinCode), null);
	customer = customerDAO.save(customer);
	return customer.getUserId();
	}

	@Override
	public Customer getCustomer(int userId)
			throws CustomerDetailsNotFoundException, MovieBookingServiceDownException {
		return customerDAO.findById(userId).orElseThrow(()->
		new CustomerDetailsNotFoundException("User  doesn't exist"));
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws MovieBookingServiceDownException {		
		return customerDAO.findAll();
	}
	
	@Override
	public int addMovie(String movieName, int movieRating, int moviePrice, String timing, String theatre)
			throws MovieBookingServiceDownException {
		MovieDetails movieDetails = new MovieDetails(movieName, movieRating, moviePrice, theatre, timing);
		movieDetails =  movieDetailsDAO.save(movieDetails);
		return movieDetails.getMovieCode();
	}

	@Override
	public int generateBillAmount(int movieCode, int noOfTickets)
			throws MovieBookingServiceDownException, MovieDetailsNotFoundException, InvalidNumberOfTickets {
		MovieDetails movieDetails =  movieDetailsDAO.findById(movieCode).orElseThrow(()->
		new MovieDetailsNotFoundException("No Movie details found with this movie code"));
		if(noOfTickets<=0)
			throw new InvalidNumberOfTickets("Please enter tickets more than zero");
		int movieAmount = noOfTickets*movieDetails.getMoviePrice();
		int gst = (int) (movieAmount*0.05);
		int totalAmount = (int) (movieAmount + gst);
		Bill bill = new Bill(totalAmount, noOfTickets, movieDetails.getMoviePrice(), gst);
		bill = billDAO.save(bill);
		return bill.getBillId();		
	}

	
	
	@Override
	public MovieDetails getMovieDetails(int movieCode)
			throws MovieDetailsNotFoundException, MovieBookingServiceDownException {
		MovieDetails movieDetails = movieDetailsDAO.findById(movieCode).orElseThrow(()->
		new MovieDetailsNotFoundException("No Movie details found with this movie code"));
		return movieDetails;
	}

	
	@Override
	public List<MovieDetails> getAllMovieDetails() throws MovieBookingServiceDownException {
		return movieDetailsDAO.findAll();
	}

	@Override
	public int generateTicketId(int movieCode, int billId, String timing, String theatre)
			throws BillDetailsNotFoundException, MovieDetailsNotFoundException,
			MovieBookingServiceDownException {
		MovieDetails movieDetails = movieDetailsDAO.findById(movieCode).orElseThrow(()->
		new MovieDetailsNotFoundException("Movie Doesn't exist"));
		Bill bill = billDAO.findById(billId).orElseThrow(()->
		new BillDetailsNotFoundException("You haven't paid ticket Bill"));
		if(timing.equals(movieDetails.getTiming())) {
			if(theatre.equals(movieDetails.getTheatre())) {
				Ticket ticket = new Ticket(new MovieDetails(movieDetails.getMovieName(), 0, 0, theatre, timing), bill);
				ticket = ticketDAO.save(ticket);
				return ticket.getTicketId();
			}else
				throw new MovieDetailsNotFoundException("Timing not found");
		}else
			throw new MovieDetailsNotFoundException("Theatre not found");
	
	}
	
	@Override
	public Ticket getTicketDetails(int ticketId)
			throws TicketDetailsNotfoundException, MovieBookingServiceDownException {
		Ticket ticket = ticketDAO.findById(ticketId).orElseThrow(()->
		new TicketDetailsNotfoundException("Ticket Id doesn't exist"));
		return ticket;
	}

	
	@Override
	public Bill getBillDetails(int billId) throws BillDetailsNotFoundException, MovieBookingServiceDownException {
		Bill bill = billDAO.findById(billId).orElseThrow(()->
		new BillDetailsNotFoundException("Bill Id doesn't exist"));
		return bill;
	}

	@Override
	public boolean deleteCustomerDetails(int userId)
			throws CustomerDetailsNotFoundException, MovieBookingServiceDownException {
		Customer customer = customerDAO.findById(userId).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer already doesn't exist"));
		customerDAO.deleteById(userId);
		return true;
	}

	@Override
	public boolean deleteMovieDetails(int movieCode)
			throws MovieDetailsNotFoundException, MovieBookingServiceDownException {
	      MovieDetails movieDetails  = movieDetailsDAO.findById(movieCode).orElseThrow(()->
		new MovieDetailsNotFoundException("No Movie details found with this movie code"));
		movieDetailsDAO.deleteById(movieCode);
		return true;
	}

	@Override
	public boolean changePassword(int userId, String oldPassword, String newPassword)
			throws CustomerDetailsNotFoundException, MovieBookingServiceDownException, PasswordDoesnotMatchException {
		Customer customer = customerDAO.findById(userId).orElseThrow(()->
		new CustomerDetailsNotFoundException("User doesn't exist"));
		if(!customer.getPassword().equals(oldPassword))
			throw new PasswordDoesnotMatchException("Old Password is incorrect");
		if(newPassword.equals(""))
			throw new PasswordDoesnotMatchException("New Password can't be empty.");
			customer.setPassword(newPassword);
			if(newPassword.equals(oldPassword))
				throw new PasswordDoesnotMatchException("Old Pssword and New Password must be different");
		customerDAO.save(customer);
		return true;
	}
}
