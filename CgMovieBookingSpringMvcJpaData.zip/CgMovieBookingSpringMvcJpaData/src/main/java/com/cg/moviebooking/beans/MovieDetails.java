package com.cg.moviebooking.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;


import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class MovieDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="movieCodeGenerator")
	@SequenceGenerator(name="movieCodeGenerator",sequenceName="movieCode_seq", initialValue=101,allocationSize=0)
	
	private int movieCode;
@NotEmpty
	private String movieName;
	@NotEmpty
	private int movieRating;
	private int moviePrice;
	private String theatre;
	private String timing;
	
	
	public MovieDetails() {
	}


	public MovieDetails(int movieCode,  String movieName,  int movieRating, int moviePrice,
			String theatre, String timing) {
		super();
		this.movieCode = movieCode;
		this.movieName = movieName;
		this.movieRating = movieRating;
		this.moviePrice = moviePrice;
		this.theatre = theatre;
		this.timing = timing;
	}


	public MovieDetails( String movieName,  int movieRating, int moviePrice, String theatre,
			String timing) {
		super();
		this.movieName = movieName;
		this.movieRating = movieRating;
		this.moviePrice = moviePrice;
		this.theatre = theatre;
		this.timing = timing;
	}


	public int getMovieCode() {
		return movieCode;
	}


	public void setMovieCode(int movieCode) {
		this.movieCode = movieCode;
	}


	public String getMovieName() {
		return movieName;
	}


	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}


	public int getMovieRating() {
		return movieRating;
	}


	public void setMovieRating(int movieRating) {
		this.movieRating = movieRating;
	}


	public int getMoviePrice() {
		return moviePrice;
	}


	public void setMoviePrice(int moviePrice) {
		this.moviePrice = moviePrice;
	}


	public String getTheatre() {
		return theatre;
	}


	public void setTheatre(String theatre) {
		this.theatre = theatre;
	}


	public String getTiming() {
		return timing;
	}


	public void setTiming(String timing) {
		this.timing = timing;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + movieCode;
		result = prime * result + ((movieName == null) ? 0 : movieName.hashCode());
		result = prime * result + moviePrice;
		result = prime * result + movieRating;
		result = prime * result + ((theatre == null) ? 0 : theatre.hashCode());
		result = prime * result + ((timing == null) ? 0 : timing.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MovieDetails other = (MovieDetails) obj;
		if (movieCode != other.movieCode)
			return false;
		if (movieName == null) {
			if (other.movieName != null)
				return false;
		} else if (!movieName.equals(other.movieName))
			return false;
		if (moviePrice != other.moviePrice)
			return false;
		if (movieRating != other.movieRating)
			return false;
		if (theatre == null) {
			if (other.theatre != null)
				return false;
		} else if (!theatre.equals(other.theatre))
			return false;
		if (timing == null) {
			if (other.timing != null)
				return false;
		} else if (!timing.equals(other.timing))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "MovieDetails [movieCode=" + movieCode + ", movieName=" + movieName + ", movieRating=" + movieRating
				+ ", moviePrice=" + moviePrice + ", theatre=" + theatre + ", timing=" + timing + "]";
	}


	
}
