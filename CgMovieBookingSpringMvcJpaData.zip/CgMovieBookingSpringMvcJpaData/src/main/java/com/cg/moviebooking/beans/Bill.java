package com.cg.moviebooking.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;


@Entity
public class Bill {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="billIdGenerator")
	@SequenceGenerator(name="billIdGenerator", sequenceName="billId_seq", initialValue=10001,allocationSize=0)
	private int billId;
	private int totalAmount;
	private int noOfTickets;
	private int pricePerMovieTicket;
	private float gst;
	

	
	public Bill() {

	}



	public Bill(int totalAmount, int noOfTickets, int pricePerMovieTicket, float gst) {
		super();
		this.totalAmount = totalAmount;
		this.noOfTickets = noOfTickets;
		this.pricePerMovieTicket = pricePerMovieTicket;
		this.gst = gst;
	}



	public Bill(int noOfTickets) {
		super();
		this.noOfTickets = noOfTickets;
	}

	
	
	public int getBillId() {
		return billId;
	}

	public void setBillId(int billId) {
		this.billId = billId;
	}

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}

	public int getNoOfTickets() {
		return noOfTickets;
	}

	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}

	public int getPricePerMovieTicket() {
		return pricePerMovieTicket;
	}

	public void setPricePerMovieTicket(int pricePerMovieTicket) {
		this.pricePerMovieTicket = pricePerMovieTicket;
	}

	public float getGst() {
		return gst;
	}

	public void setGst(float gst) {
		this.gst = gst;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + billId;
		result = prime * result + Float.floatToIntBits(gst);
		result = prime * result + noOfTickets;
		result = prime * result + pricePerMovieTicket;
		result = prime * result + totalAmount;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bill other = (Bill) obj;
		if (billId != other.billId)
			return false;
		if (Float.floatToIntBits(gst) != Float.floatToIntBits(other.gst))
			return false;
		if (noOfTickets != other.noOfTickets)
			return false;
		if (pricePerMovieTicket != other.pricePerMovieTicket)
			return false;
		if (totalAmount != other.totalAmount)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Bill [billId=" + billId + ", totalAmount=" + totalAmount + ", noOfTickets=" + noOfTickets
				+ ", pricePerMovieTicket=" + pricePerMovieTicket + ", gst=" + gst + "]";
	}
	
	
}
