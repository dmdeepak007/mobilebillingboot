package com.cg.moviebooking.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.moviebooking.beans.Customer;

public interface CustomerDAO extends JpaRepository<Customer, Integer>{

}
