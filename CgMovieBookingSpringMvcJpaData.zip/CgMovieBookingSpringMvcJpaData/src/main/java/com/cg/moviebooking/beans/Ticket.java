package com.cg.moviebooking.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Ticket {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ticketIdGenerator")
	@SequenceGenerator(name="ticketIdGenerator",sequenceName="ticketId_seq",initialValue=1, allocationSize=0)
	private int ticketId;
	private String theatre;
	private String timing;
	
	@MapKey
	@OneToOne
	private MovieDetails movie;
	
	@MapKey
	@OneToOne
	private Bill bill;

	@MapKey
	@ManyToOne
	private Customer customer;
	
	public Ticket() {
	}


	
	public Ticket(String theatre, String timing, MovieDetails movie, Bill bill) {
		super();
		this.theatre = theatre;
		this.timing = timing;
		this.movie = movie;
		this.bill = bill;
	}



	public Ticket(MovieDetails movie, Bill bill) {
		super();
		this.movie = movie;
		this.bill = bill;
	}



	public int getTicketId() {
		return ticketId;
	}



	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}



	public String getTheatre() {
		return theatre;
	}



	public void setTheatre(String theatre) {
		this.theatre = theatre;
	}



	public String getTiming() {
		return timing;
	}



	public void setTiming(String timing) {
		this.timing = timing;
	}



	public MovieDetails getMovie() {
		return movie;
	}



	public void setMovie(MovieDetails movie) {
		this.movie = movie;
	}



	public Bill getBill() {
		return bill;
	}



	public void setBill(Bill bill) {
		this.bill = bill;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bill == null) ? 0 : bill.hashCode());
		result = prime * result + ((movie == null) ? 0 : movie.hashCode());
		result = prime * result + ((theatre == null) ? 0 : theatre.hashCode());
		result = prime * result + ticketId;
		result = prime * result + ((timing == null) ? 0 : timing.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ticket other = (Ticket) obj;
		if (bill == null) {
			if (other.bill != null)
				return false;
		} else if (!bill.equals(other.bill))
			return false;
		if (movie == null) {
			if (other.movie != null)
				return false;
		} else if (!movie.equals(other.movie))
			return false;
		if (theatre == null) {
			if (other.theatre != null)
				return false;
		} else if (!theatre.equals(other.theatre))
			return false;
		if (ticketId != other.ticketId)
			return false;
		if (timing == null) {
			if (other.timing != null)
				return false;
		} else if (!timing.equals(other.timing))
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Ticket [ticketId=" + ticketId + ", theatre=" + theatre + ", timing=" + timing + ", movie=" + movie
				+ ", bill=" + bill + "]";
	}

	
	
}
