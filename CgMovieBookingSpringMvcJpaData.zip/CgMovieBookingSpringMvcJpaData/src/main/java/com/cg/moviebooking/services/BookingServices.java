package com.cg.moviebooking.services;

import java.util.List;

import com.cg.moviebooking.beans.Address;
import com.cg.moviebooking.beans.Bill;
import com.cg.moviebooking.beans.Customer;
import com.cg.moviebooking.beans.MovieDetails;
import com.cg.moviebooking.beans.Ticket;
import com.cg.moviebooking.exceptions.BillDetailsNotFoundException;
import com.cg.moviebooking.exceptions.CustomerDetailsNotFoundException;
import com.cg.moviebooking.exceptions.InvalidNumberOfTickets;
import com.cg.moviebooking.exceptions.MovieBookingServiceDownException;
import com.cg.moviebooking.exceptions.MovieDetailsNotFoundException;
import com.cg.moviebooking.exceptions.PasswordDoesnotMatchException;
import com.cg.moviebooking.exceptions.TicketDetailsNotfoundException;

public interface BookingServices {

int acceptCustomerDetails(String name,  String emailId,  String dateOfBirth,
		 String password,   String city,  String state,  int pinCode) throws MovieBookingServiceDownException;
	
	int addMovie(String movieName,  int movieRating, int moviePrice, String timing,
			String theatre) throws MovieBookingServiceDownException;
	
	int generateBillAmount(int movieCode, int noOfTickets) throws MovieBookingServiceDownException, 
	MovieDetailsNotFoundException, InvalidNumberOfTickets;
	
	List<MovieDetails> getAllMovieDetails() throws MovieBookingServiceDownException;
	
	Ticket getTicketDetails(int ticketId) throws TicketDetailsNotfoundException, MovieBookingServiceDownException;
	
	MovieDetails getMovieDetails(int movieCode) throws MovieDetailsNotFoundException, MovieBookingServiceDownException;
	
	Bill getBillDetails(int billId) throws BillDetailsNotFoundException, MovieBookingServiceDownException;
	
	boolean deleteCustomerDetails(int userId) throws CustomerDetailsNotFoundException, MovieBookingServiceDownException;
	
	boolean deleteMovieDetails(int movieCode) throws MovieDetailsNotFoundException, MovieBookingServiceDownException;
	
	boolean changePassword(int userId, String oldPassword, String newPassword) throws
	CustomerDetailsNotFoundException, MovieBookingServiceDownException, PasswordDoesnotMatchException;
	
	int generateTicketId (int movieCode, int billId, String timings, String theatre) throws
	BillDetailsNotFoundException, MovieDetailsNotFoundException, MovieBookingServiceDownException;
	
	public Customer getCustomer(int userId)
			throws CustomerDetailsNotFoundException, MovieBookingServiceDownException;

	List<Customer> getAllCustomerDetails() throws MovieBookingServiceDownException;
	
}
