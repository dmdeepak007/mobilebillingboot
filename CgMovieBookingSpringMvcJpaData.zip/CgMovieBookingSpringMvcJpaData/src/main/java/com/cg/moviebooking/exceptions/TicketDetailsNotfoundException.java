package com.cg.moviebooking.exceptions;

@SuppressWarnings("serial")
public class TicketDetailsNotfoundException extends Exception {

	public TicketDetailsNotfoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TicketDetailsNotfoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public TicketDetailsNotfoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TicketDetailsNotfoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TicketDetailsNotfoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
