package com.cg.moviebooking.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.moviebooking.beans.Customer;
import com.cg.moviebooking.daoservices.CustomerDAO;
import com.cg.moviebooking.exceptions.CustomerDetailsNotFoundException;
import com.cg.moviebooking.exceptions.MovieBookingServiceDownException;
import com.cg.moviebooking.exceptions.PasswordDoesnotMatchException;
import com.cg.moviebooking.services.BookingServices;

@Controller
public class CustomerController {

	@Autowired
	private BookingServices bookingServices;

	
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws MovieBookingServiceDownException   {
		if(result.hasErrors())
			return new ModelAndView("registrationPage");
		int userID = bookingServices.acceptCustomerDetails(customer.getName(), customer.getEmailId(), customer.getDateOfBirth(), customer.getPassword(), customer.getAddress().getCity(), customer.getAddress().getState(), customer.getAddress().getPinCode());
		ModelAndView model = new ModelAndView("registrationPage", "userID", userID);
		model.addObject("open","1");
		return model;
	}
	
	@RequestMapping("/loginCustomer")
	public ModelAndView logInCustomerAction(@Valid@ModelAttribute Customer customer, BindingResult result) throws MovieBookingServiceDownException   {
		try {
			Customer customer1 = bookingServices.getCustomer(customer.getUserId());
			if(!customer1.getPassword().equals(customer.getPassword())) {
				ModelAndView model = new ModelAndView("indexPage", "Message","Password is incorrect");
				return model;
			}
			if(customer.getUserId()==1001  && customer.getPassword().equals("deepak123")){
				ModelAndView model = new ModelAndView("adminPage","customer","Welcome " + customer.getName());
				return model;
			}
			else {
				ModelAndView model = new ModelAndView("loginSuccessfullPage","customer","Welcome " + customer.getName());
				return model;
			}
		} catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("indexPage", "Message", e.getMessage());
		}
		}
	
	@RequestMapping("/passwordChange")
	public ModelAndView changePasswordAction(@Valid @RequestParam("newPassword") String newPassword,@RequestParam("oldPassword") String oldPassword,  @ModelAttribute Customer customer, BindingResult result) throws MovieBookingServiceDownException   {
	
			try {
			
				boolean customer1 = bookingServices.changePassword(customer.getUserId(), oldPassword, newPassword);
				ModelAndView model = new ModelAndView("changePasswordPage","message","Password Succesfully Changed");
				return model;
			
			} catch (CustomerDetailsNotFoundException | PasswordDoesnotMatchException e) {
				return new ModelAndView("changePasswordPage", "message", e.getMessage());
			}
		}
	
	@RequestMapping("/getSingleCustomer")
	public ModelAndView getSingleCustomerAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws MovieBookingServiceDownException   {
		try {
		Customer customer1 = bookingServices.getCustomer(customer.getUserId());
			ModelAndView model = new ModelAndView("customerDetailsPage", "customer1", customer1);
			model.addObject("open","1");
			return model;
		} catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("customerDetailsPage", "message", e.getMessage());
		}
	}
	
	@RequestMapping("/getAllCustomer")
	public ModelAndView getAllCustomerAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws MovieBookingServiceDownException   {
		List<Customer> lists = bookingServices.getAllCustomerDetails();
		ModelAndView model = new ModelAndView("allCustomerDetailsPage","lists",lists);
		model.addObject("open","1");
				return model;
	}
	
	@RequestMapping("/deleteParticularCustomer")
	public ModelAndView deleteCustomerAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws MovieBookingServiceDownException   {
		try {		
			Customer customer1 = bookingServices.getCustomer(customer.getUserId());
		if(customer1.getUserId()==1001)
			return new ModelAndView("deleteCustomerPage","message","This is Your own Id, You can't destroy yourself");
	      bookingServices.deleteCustomerDetails(customer.getUserId());

		return new ModelAndView("deleteCustomerPage","message","User Successfully Deleted.");

		} catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("deleteCustomerPage","message",e.getMessage());
		
		}
	}
	
	

}
