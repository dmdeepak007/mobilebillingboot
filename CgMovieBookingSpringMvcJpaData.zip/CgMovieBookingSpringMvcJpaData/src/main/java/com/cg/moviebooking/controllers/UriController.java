package com.cg.moviebooking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.moviebooking.beans.Customer;



@Controller
public class UriController {

	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/frame1")
	public String getframePage() {
		return "frame1Page";
	}
	
	@RequestMapping("/index")
	public String getHomePage() {
		return "indexPage";
	}
	
	@RequestMapping("/admin")
	public String getAdminHomePage() {
		return "adminPage";
	}
	
	@RequestMapping("/registration")
	public String getregistrationPage() {
		return "registrationPage";
	}
	
	@RequestMapping("/changePassword")
	public String getloginPage() {
		return "changePasswordPage";
	}
	
	@RequestMapping("/customerDetails")
	public String getCustomerDetailsPage() {
		return "customerDetailsPage";
	}
	
	@RequestMapping("/allCustomerDetails")
	public String getAllCustomerDetailsPage() {
		return "allCustomerDetailsPage";
	}
	
	@RequestMapping("/deleteCustomer")
	public String deleteCustomerPage() {
		return "deleteCustomerPage";
	}
	
	
	@ModelAttribute
	public Customer getCustomer() {
		return new Customer();
	}
	
}
