package com.cg.moviebooking.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.moviebooking.beans.MovieDetails;

public interface MovieDetailsDAO extends JpaRepository<MovieDetails, Integer>{

}
