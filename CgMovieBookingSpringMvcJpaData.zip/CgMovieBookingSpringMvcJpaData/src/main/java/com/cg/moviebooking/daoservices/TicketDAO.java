package com.cg.moviebooking.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.moviebooking.beans.Ticket;

public interface TicketDAO extends JpaRepository<Ticket, Integer> {

}
