package com.cg.moviebooking.beans;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.validation.Valid;
import javax.validation.constraints.Email;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Customer {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="userIdGenerator")
@SequenceGenerator(name="userIdGenerator",sequenceName="userId_seq", initialValue=1001,allocationSize=0)
	private int userId;

@NotEmpty(message="{NotEmpty.customer.name}")
	private String name;

@NotEmpty(message="{NotEmpty.customer.emailId}")
@Email(message="{Email.customer.emailId}")
	private String emailId;

@NotEmpty(message="{NotEmpty.customer.dateOfBirth}")
	private String dateOfBirth;

@NotEmpty(message="{NotEmpty.customer.password}")
	private String password;

@Valid
@Embedded
private Address address;

@OneToMany(cascade=CascadeType.ALL, mappedBy="customer", fetch=FetchType.EAGER)
@MapKey
private List<Ticket>tickets;

public Customer() {
}

public Customer(int userId,  String name,  String emailId,  String dateOfBirth,
		 String password,  Address address, List<Ticket> tickets) {
	super();
	this.userId = userId;
	this.name = name;
	this.emailId = emailId;
	this.dateOfBirth = dateOfBirth;
	this.password = password;
	this.address = address;
	this.tickets = tickets;
}


public Customer( String name,  String emailId,  String dateOfBirth,
		 String password,  Address address, List<Ticket> tickets) {
	super();
	this.name = name;
	this.emailId = emailId;
	this.dateOfBirth = dateOfBirth;
	this.password = password;
	this.address = address;
	this.tickets = tickets;
}

public int getUserId() {
	return userId;
}

public void setUserId(int userId) {
	this.userId = userId;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getEmailId() {
	return emailId;
}

public void setEmailId(String emailId) {
	this.emailId = emailId;
}

public String getDateOfBirth() {
	return dateOfBirth;
}

public void setDateOfBirth(String dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public Address getAddress() {
	return address;
}

public void setAddress(Address address) {
	this.address = address;
}

public List<Ticket> getTickets() {
	return tickets;
}

public void setTickets(List<Ticket> tickets) {
	this.tickets = tickets;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((address == null) ? 0 : address.hashCode());
	result = prime * result + ((dateOfBirth == null) ? 0 : dateOfBirth.hashCode());
	result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	result = prime * result + ((password == null) ? 0 : password.hashCode());
	result = prime * result + ((tickets == null) ? 0 : tickets.hashCode());
	result = prime * result + userId;
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Customer other = (Customer) obj;
	if (address == null) {
		if (other.address != null)
			return false;
	} else if (!address.equals(other.address))
		return false;
	if (dateOfBirth == null) {
		if (other.dateOfBirth != null)
			return false;
	} else if (!dateOfBirth.equals(other.dateOfBirth))
		return false;
	if (emailId == null) {
		if (other.emailId != null)
			return false;
	} else if (!emailId.equals(other.emailId))
		return false;
	if (name == null) {
		if (other.name != null)
			return false;
	} else if (!name.equals(other.name))
		return false;
	if (password == null) {
		if (other.password != null)
			return false;
	} else if (!password.equals(other.password))
		return false;
	if (tickets == null) {
		if (other.tickets != null)
			return false;
	} else if (!tickets.equals(other.tickets))
		return false;
	if (userId != other.userId)
		return false;
	return true;
}

@Override
public String toString() {
	return "Customer [userId=" + userId + ", name=" + name + ", emailId=" + emailId + ", dateOfBirth=" + dateOfBirth
			+ ", password=" + password + ", address=" + address + ", tickets=" + tickets + "]";
}
	
}
