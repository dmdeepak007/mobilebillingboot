package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class OpenAccountPage {

		@FindBy(how=How.ID,id="firstName")
		private WebElement firstName;
		
		@FindBy(how = How.ID, id="lastName")
		private WebElement lastName;
		
		@FindBy(how = How.ID, id="emailID")
		private WebElement emailId;
		
		@FindBy(how = How.ID, id="dateOfBirth")
		private WebElement dateOfBirth;
		
		@FindBy(how = How.ID, id="billingAddress.city")
		private WebElement city;
		
		@FindBy(how = How.ID, id="billingAddress.state")
		private WebElement state;
		
		@FindBy(how = How.ID, id="billingAddress.pinCode")
		private WebElement pinCode;
		
		@FindBy(how=How.XPATH,xpath="/html/body/div[1]/table/tbody/tr[8]/td/input")
		private WebElement button1;
		
		@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr/td/input")
		private WebElement button2;
		
		@FindBy(how = How.ID, id="firstName.errors")
		private WebElement actualErrorMessage1;
		
		@FindBy(how=How.XPATH,xpath="//*[@id=\"lastName.errors\"]")
		private WebElement actualErrorMessage2;
		
		@FindBy(how=How.XPATH,xpath="//*[@id=\"emailID.errors\"]")
		private WebElement actualErrorMessage3;
		
		@FindBy(how=How.XPATH,xpath="//*[@id=\"dateOfBirth.errors\"]")
		private WebElement actualErrorMessage4;
		
		@FindBy(how=How.XPATH,xpath="//*[@id=\"billingAddress.city.errors\"]")
		private WebElement actualErrorMessage5;
		
		@FindBy(how=How.XPATH,xpath="//*[@id=\"billingAddress.state.errors\"]")
		private WebElement actualErrorMessage6;
		
		@FindBy(how=How.XPATH,xpath="/html/body/div[1]/table/tbody/tr[3]/td[2]")
		private WebElement Message;

		public OpenAccountPage() {
		}

		public String getFirstName() {
			return firstName.getAttribute("value");
		}

		public void setFirstName(String firstName) {
			this.firstName.sendKeys(firstName);
		}

		public String getLastName() {
			return lastName.getAttribute("value");
		}

		public void setLastName(String lastName) {
			this.lastName.sendKeys(lastName);
		}

		public String getEmailId() {
			return emailId.getAttribute("value");
		}

		public void setEmailId(String emailId) {
			this.emailId.sendKeys(emailId);
		}

		public String getDateOfBirth() {
			return dateOfBirth.getAttribute("value");
		}

		public void setDateOfBirth(String dateOfBirth) {
			this.dateOfBirth.sendKeys(dateOfBirth);
		}

		public String getCity() {
			return city.getAttribute("value");
		}

		public void setCity(String city) {
			this.city.sendKeys(city);
		}

		public String getState() {
			return state.getAttribute("value");
		}

		public void setState(String state) {
			this.state.sendKeys(state);
		}

		public String getPinCode() {
			return pinCode.getAttribute("value");
		}

		public void setPinCode(String pinCode) {
			this.pinCode.clear();
			this.pinCode.sendKeys(pinCode);
		}
		public String getActualErrorMessage1() {
			return actualErrorMessage1.getText();
		}
		public String getActualErrorMessage2() {
			return actualErrorMessage2.getText();
		}
		public String getActualErrorMessage3() {
			return actualErrorMessage3.getText();
		}
		public String getActualErrorMessage4() {
			return actualErrorMessage4.getText();
		}
		public String getActualErrorMessage5() {
			return actualErrorMessage5.getText();
		}
		public String getActualErrorMessage6() {
			return actualErrorMessage6.getText();
		}
		
		public String getMessage() {
			return Message.getText();
		}
		
		public void clickSignUp() {
			button1.click();
		}
		public void goHomePage() {
			button2.click();
		}
		
}
