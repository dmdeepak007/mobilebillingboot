package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class allCustomerDetailsPage {

	@FindBy(how=How.XPATH,xpath="//*[@id=\"customer\"]/table/tbody/tr/td/input")
	private WebElement button;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[1]/td[1]")
	private WebElement Message1;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[1]/td[2]")
	private WebElement Message2;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[7]/td[1]")
	private WebElement Message3;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[7]/td[2]")
	private WebElement Message4;

	public allCustomerDetailsPage() {
	}

	public String getMessage1() {
		return Message1.getText();
	}

	public String getMessage2() {
		return Message2.getText();
	}

	public String getMessage3() {
		return Message3.getText();
	}

	public String getMessage4() {
		return Message4.getText();
	}

public void clickgetallcustomer() {
	button.click();
}

	
	
	
	
	
}
