package com.cg.mobilebilling.stepdefinations;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.OpenAccountPage;
import com.cg.mobilebilling.pagebeans.OpenPostpaidMobileAccountPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OpenPostpaidMobileAccountStepDefination {
	
	private WebDriver driver;
	private OpenPostpaidMobileAccountPage openMobilePage;
	
	@Given("^User is on open Postpaid Mobile Account Page$")
	public void user_is_on_open_Postpaid_Mobile_Account_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://localhost:4049/openPostpaidMobileAccount");
		openMobilePage = PageFactory.initElements(driver, OpenPostpaidMobileAccountPage.class);
	}

	@When("^User enter his correct customerId and planId click on submit button$")
	public void user_enter_his_correct_customerId_and_planId_click_on_submit_button() throws Throwable {
	  openMobilePage.setCustomerId("20025");
	  openMobilePage.setPlanId("1001");
	  openMobilePage.clickSignUp();
	}

	@Then("^User is redirected to postpaid mobile account success page and message gets displayed$")
	public void user_is_redirected_to_postpaid_mobile_account_success_page_and_message_gets_displayed() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Account Opened";
		assertEquals(expectedTitle, actualTitle);
		String actualMessage = openMobilePage.getMessage();
		String expectedMessage = "987654350";
		System.out.println(actualMessage);
		assertEquals(expectedMessage, actualMessage);
	}
	
	@When("^User click on home page button(\\d+)$")
	public void user_click_on_home_page_button(int arg1) throws Throwable {
		openMobilePage.goHomePage();
	}

	@Then("^User is redirected to home page(\\d+)$")
	public void user_is_redirected_to_home_page(int arg1) throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="WebApp1";
		assertEquals(expectedTitle, actualTitle);
	}
}
