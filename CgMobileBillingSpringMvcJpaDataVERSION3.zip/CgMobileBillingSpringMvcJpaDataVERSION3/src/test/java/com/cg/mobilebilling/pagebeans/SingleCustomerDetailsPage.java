package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SingleCustomerDetailsPage {

	@FindBy(how=How.ID,id="customerID")
	private WebElement customerID;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div/table/tbody/tr[2]/td/input")
	private WebElement button;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[1]/td[1]")
	private WebElement message1;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[1]/td[2]")
	private WebElement message2;

	public SingleCustomerDetailsPage() {
	}

	public String getCustomerID() {
		return customerID.getAttribute("value");
	}

	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}

	public void clickgetdetails() {
		button.click();
	}

	public String getMessage1() {
		return message1.getText();
	}

	public String getMessage2() {
		return message2.getText();
	}

}
