package com.cg.mobilebilling.stepdefinations;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.OpenAccountPage;
import com.cg.mobilebilling.pagebeans.SingleCustomerDetailsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SingleCustomerDetailsStepDefination {
	
	public WebDriver driver;
	public SingleCustomerDetailsPage detailsPage;
	
	@Given("^User is on get customer details page$")
	public void user_is_on_get_customer_details_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://localhost:4049/getCustomerDetails");
		detailsPage = PageFactory.initElements(driver, SingleCustomerDetailsPage.class);
	}

	@When("^User enters correct customerId$")
	public void user_enters_correct_customerId() throws Throwable {
	detailsPage.setCustomerID("20026");
	detailsPage.clickgetdetails();
	}

	@Then("^User is provided with customer details on same page$")
	public void user_is_provided_with_customer_details_on_same_page() throws Throwable {
		String actualMessage1 = detailsPage.getMessage1();
		String expectedMessage1 = "First Name :";
		//System.out.println(actualMessage1);
		assertEquals(expectedMessage1, actualMessage1);
		
		String actualMessage2 = detailsPage.getMessage2();
		String expectedMessage2 = "Vivek";
		//System.out.println(actualMessage2);
		assertEquals(expectedMessage2, actualMessage2);
	}
}
