package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class OpenPostpaidMobileAccountPage {

	@FindBy(how=How.ID,id="customerID")
	private WebElement customerId;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/table/tbody/tr[2]/td[2]/input")
	private WebElement planId;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/table/tbody/tr[3]/td/input")
	private WebElement button1;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr/td/input")
	private WebElement button2;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/table/tbody/tr/td[2]")
	private WebElement message;

	public OpenPostpaidMobileAccountPage() {
	}

	public String getCustomerId() {
		return customerId.getAttribute("value");
	}

	public void setCustomerId(String customerId) {
		this.customerId.clear();
		this.customerId.sendKeys(customerId);
	}

	public String getPlanId() {
		return planId.getAttribute("value");
	}

	public void setPlanId(String planId) {
		this.planId.sendKeys(planId);
	}

	public void clickSignUp() {
		button1.click();
	}
	public void goHomePage() {
		button2.click();
	}

	public String getMessage() {
		return message.getText();
	}




	
	
	
	
}
