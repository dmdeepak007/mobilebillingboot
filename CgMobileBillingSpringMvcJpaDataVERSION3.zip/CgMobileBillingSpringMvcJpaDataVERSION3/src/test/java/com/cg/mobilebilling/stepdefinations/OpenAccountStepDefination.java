package com.cg.mobilebilling.stepdefinations;

import static org.junit.Assert.assertEquals;

import java.sql.Driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.mobilebilling.pagebeans.OpenAccountPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OpenAccountStepDefination {

	private WebDriver driver;
	private OpenAccountPage openAccountPage;
	
	@Given("^User is on open account Page$")
	public void user_is_on_open_account_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://localhost:4049/registration");
		openAccountPage = PageFactory.initElements(driver, OpenAccountPage.class);
	}

	@When("^User enter his correct data and click on submit button$")
	public void user_enter_his_correct_data_and_click_on_submit_button() throws Throwable {
		openAccountPage.setFirstName("Vivek");
		openAccountPage.setLastName("Singla");
		openAccountPage.setEmailId("singlav787@gmail.com");
		openAccountPage.setDateOfBirth("18/09/1996");
		openAccountPage.setCity("Gobindgarh");
		openAccountPage.setState("Punjab");
		openAccountPage.setPinCode("124789");
		openAccountPage.clickSignUp();
	}

	@Then("^User is redirected to registration page and message gets displayed$")
	public void user_is_redirected_to_registration_page_and_message_gets_displayed() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Registration Successfull";
		assertEquals(expectedTitle, actualTitle);
		String actualMessage = openAccountPage.getMessage();
		String expectedMessage = "20026";
		System.out.println(actualMessage);
		assertEquals(expectedMessage, actualMessage);
	}

@When("^User enters data but with some empty fillings and click on submit button$")
public void user_enters_data_but_with_some_empty_fillings_and_click_on_submit_button() throws Throwable {
	openAccountPage.setFirstName("");
	openAccountPage.setLastName("");
	openAccountPage.setEmailId("");
	openAccountPage.setDateOfBirth("");
	openAccountPage.setCity("");
	openAccountPage.setState("");
	openAccountPage.setPinCode("");
	openAccountPage.clickSignUp();
}

@Then("^User is given error message$")
public void user_is_given_error_message() throws Throwable {
	 String exString1= "Please Enter First Name";
	   assertEquals(exString1,openAccountPage.getActualErrorMessage1());	   
	   String exString2= "Please Enter Last Name";
	   assertEquals(exString2,openAccountPage.getActualErrorMessage2());
	   String exString3= "Please Enter EmailId";
	   assertEquals(exString3,openAccountPage.getActualErrorMessage3());
	   String exString4= "Please Enter Date of Birth";
	   assertEquals(exString4,openAccountPage.getActualErrorMessage4());
	   String exString5= "Please Enter City";
	   assertEquals(exString5,openAccountPage.getActualErrorMessage5());
	   String exString6= "Please Enter State";
	   assertEquals(exString6,openAccountPage.getActualErrorMessage6());
	
}

@When("^User click on home page button$")
public void user_click_on_home_page_button() throws Throwable {
	openAccountPage.goHomePage();
}

@Then("^User is redirected to home page$")
public void user_is_redirected_to_home_page() throws Throwable {
	String actualTitle = driver.getTitle();
	String expectedTitle="WebApp1";
	assertEquals(expectedTitle, actualTitle);
}


	
	
	
}
