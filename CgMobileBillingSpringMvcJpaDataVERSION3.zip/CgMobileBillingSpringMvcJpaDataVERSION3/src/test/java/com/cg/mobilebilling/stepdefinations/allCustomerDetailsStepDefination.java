package com.cg.mobilebilling.stepdefinations;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.SingleCustomerDetailsPage;
import com.cg.mobilebilling.pagebeans.allCustomerDetailsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class allCustomerDetailsStepDefination {
	
	public WebDriver driver;
	public allCustomerDetailsPage alldetailsPage;
	
	
	@Given("^User is on all customer details page$")
	public void user_is_on_all_customer_details_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://localhost:4049/allCustomerDetails");
		alldetailsPage = PageFactory.initElements(driver, allCustomerDetailsPage.class);
	}

	@When("^User just clicks the All Customer Details Button$")
	public void user_just_clicks_the_All_Customer_Details_Button() throws Throwable {
	  alldetailsPage.clickgetallcustomer();
	}

	@Then("^User is provided with all customer details on same page$")
	public void user_is_provided_with_all_customer_details_on_same_page() throws Throwable {
		String actualMessage1 = alldetailsPage.getMessage1();
		String expectedMessage1 = "First Name";
		System.out.println(actualMessage1);
		assertEquals(expectedMessage1, actualMessage1);
		
		String actualMessage2 = alldetailsPage.getMessage2();
		String expectedMessage2 = "Rishabh";
		System.out.println(actualMessage2);
		assertEquals(expectedMessage2, actualMessage2);
		String actualMessage3 = alldetailsPage.getMessage3();
		String expectedMessage3 = "Last Name";
		System.out.println(actualMessage3);
		assertEquals(expectedMessage3, actualMessage3);
		
		String actualMessage4 = alldetailsPage.getMessage4();
		String expectedMessage4 = "Goel";
		System.out.println(actualMessage4);
		assertEquals(expectedMessage4, actualMessage4);
	}
}
